/** Name: Bryan Bravo
 * Date:3/28/21
 * Assignment 2
 * Panther ID 6059483
 * IDE used Apache NetBeans 12.3
 */

package Assignment2;
//UndergradStudent.java should inherit from Student.java
//Private data field for hobby as requested
public class UndergradStudent extends Student {
    private String hobby;
    
   //The Constructor should instantiate an instance of UndergradStudent with the name, age, major by referencing them in the super class 
    //with also adding hobby
    public UndergradStudent(String name, int age, String major, String hobby){
        super(name, age, major);
        this.hobby = hobby;
    }

    //setMajor method is added to the subclass
    //Also Undergraduate Student and has changed majors to should appear in output when running the program.
    @Override
    public void setMajor (String newMajor) {
        System.out.println("(Undergraduate Student)" + getName() + ",has changed major from " + super.major + " to "+ newMajor);
        super.major = newMajor;
    }
    //Should override Person class method for setAge()
//Should display Undergraduate Student and has changed age from " " to ""
    @Override
    public void setAge(int newAge) {
        System.out.println("(Undergraduate Student)" + getName() + ", has changed age from " + getAge() + " to" + newAge);
        super.setAge(newAge);
    }
    //Should display what the Undergraduate Student likes as their hobby
    @Override
    public String toString() {
        return "(Undergraduate Student)" + super.toString() + ", likes " + hobby;
    }

}