/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assignment2;
// Should inherit frtom Person.Java
public class Student extends Person {
    protected String major;
    //Constructor Instantiates an instance of Student with name, age, and major 
    public Student(String name, int age, String major) {
        super(name, age);
        this.major = major;
    }
    //Should display the text FIU student
    @Override
    public String getName() {
        return super.getName() + ", FIU student";
    }
    //Displays how old the Student and person is but also displays the major they are in
    @Override
    public String toString() {
        return "(Student)(Person)" + getName() + "," + getAge() + " Years old, Majored in: " + major;
        
    }
    public void setMajor(String major) {
        this.major = major;
    }
}