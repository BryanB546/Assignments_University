#Bryan Bravo
#Date:11/11/20
#Excercise 1.3 (Recursive Function in Python A(m,n) Done on Python 3.8.5
#Recursion Function used
def A(m,n):
# Start of first condition which is m = 0.
    if m ==0:
        return n+1
# Start of Second Condition m > 0, n = 0.
    elif m > 0 and n ==0:
        return A(m - 1,1)
#Start of third condition m > 0, n > 0.
    elif m > 0 and n > 0:
        return A(m - 1,A(m,n - 1))
#To Show results.
numbs = A(2,7)
print(('Result:'),numbs)
