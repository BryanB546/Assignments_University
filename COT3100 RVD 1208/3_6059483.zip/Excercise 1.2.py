#Bryan Bravo
#Excercise 1.2
#11/11/20
def Even_numSum(n):
  if n < 1:
    return 0
  elif n%2 == 0:
    return Even_numSum(n-1)
  else:
    return n + Even_numSum(n-2)
n=int(input('Input Number:'))
print('Result:',Even_numSum(n))
