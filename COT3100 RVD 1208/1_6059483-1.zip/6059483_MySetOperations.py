#Bryan Bravo ID:6059483 Date:9/25/20
def MyIsEmpty(s1):
    if len(s1) == 0:
        return 'T'
    else:
        return 'F'
#Below is the function for Intersection
def MyInterSection(s1,s2):
        InteractionOfSet = set()
        for c in s1:
            if c in s2:
                InteractionOfSet.add(c)
        return InteractionOfSet
#Below is the funtion for the Union
def MyUnion(s1,s2): 
                UnionOfSet = set()
                for c in s1:
                    if c not in UnionOfSet:
                        UnionOfSet.add(c)
                        for d in s2:
                            if d not in UnionOfSet:
                                UnionOfSet.add(d)
                return UnionOfSet
#Below is an example of the sets used.                            
s1 = {1,2,3,4,5,6,7}
s2 = {2,3,6,8,9}
s3 = {}

print("is Set 1 empty:",MyIsEmpty(s1))
print("is Set 2 empty:",MyIsEmpty(s2))
print("is Set 3 empty:",MyIsEmpty(s3))
print("Intersection of A (Set1) and B (Set2) is:",MyInterSection(s1,s2))
print("Intersection of A (Set1)and C (Set3) is:",MyInterSection(s1,s3))
print("The Union of A (Set1) and B (Set2):",MyUnion(s1,s2))

