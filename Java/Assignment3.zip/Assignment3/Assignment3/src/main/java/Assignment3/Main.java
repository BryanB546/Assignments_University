//Bryan Bravo Date:4/11/2021
//Panther ID:6059483
//IDE USED:Apache Netbeans 12.3
//Assignment 3 Part 1 Histogram from txt files test1,2,3 
//All three test results are located in the Result 1 with tests2,3.txt document
package Assignment3;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    // Should access the path to the document titled test1.txt
    public static void main(String[] args) throws IOException {
        File file = new
            File("G:\\Assignment3\\test1.txt");
        
        Scanner scan = new Scanner(file);
        //Array will store the Integers
        ArrayList<Integer> ints = new ArrayList<>();
        
        int others = 0;
        int count = 0;
        
        try {
            while (scan.hasNext()) {
                
                String temp = scan.nextLine();
                boolean flag = true;
                // Will check to see if the value inputted will be an Integer or not.
                for(int i = 0; i<temp.length(); i++) {
                    
                    if(!Character.isDigit(temp.charAt(i))) {
                        
                        others ++;
                        flag = false;
                        
                        break;
                    }
                }
                // Will check if it is an integer than add it to the list
                if(flag) {
                    
                    int num = Integer.parseInt(temp);
                    ints.add(num);
                    
                }
            }
        }
        //scanner will close
        finally {
            scan.close();
        }
        // Will check the range for all the integers
        int range[] = new int[10];
        //Loop
        for(int i=0; i < ints.size(); i++) {
            //will check the range and will add it to the range array
            
            if(ints.get(i) >=1 && ints.get(i) <= 10 ) {
            
            range[0]++;
            count++;
        }
            else if(ints.get(i) >=11 && ints.get(i) <=20 ) {
                range[1]++;
                count++;
            }
            
            else if(ints.get(i) >=21 && ints.get(i) <=30 ) {
                    range[2]++;
                    count++;
                    }
                    
            else if(ints.get(i) >=31 && ints.get(i) <=40 ) {
                    range[3]++;
                    count++;
                    }
                    
            else if(ints.get(i) >=41 && ints.get(i) <=50 ) {
                    range[4]++;
                    count++;
                    }
                    
            else if(ints.get(i) >=51 && ints.get(i) <=60 ) {
                    range[5]++;
                    count++;
                    }
                    
            else if(ints.get(i) >=61 && ints.get(i) <=70 ) {
                    range[6]++;
                    count++;
                    }
            
            else if(ints.get(i) >=71 && ints.get(i) <=80 ) {
                    range[7]++;
                    count++;
                    }
            
            else if(ints.get(i) >=81 && ints.get(i) <=90 ) {
                    range[8]++;
                    count++;
                    }
            
            else if(ints.get(i) >=91 && ints.get(i) <=100 ) {
                    range[9]++;
                    count++;
                    }
            
            else {
                    others++;
                    
                    }
        }
        //Create a Filewriter where it will allow the information to be displayed in the result1.txt and where the file is being accessed from.
            FileWriter Fwriter = new 
                FileWriter("G:\\Assignment3\\result1.txt");
            
            Fwriter.write("Reading Integers from File: G:\\Assignment3\\test1.txt");
            
            Fwriter.write("\nNumbers of Integers in Interval [1-100] : "+count);
            
            Fwriter.write("\nOthers : "+others);
            
            Fwriter.write("\nHistogram");
            
            int min = 1;
            int max = 10;
            // Should loop print the Histogram
            for(int i=0;i< range.length;i++) {
                Fwriter.write("\n" +min+"-" +max+" | ");
                
                for(int j=0; j<range[i];j++) {
                    Fwriter.write("*");
                }
                min = min+10;
                max = max+10;
                
            }
            //The writer will close
            Fwriter.close();
        }
    }
    
