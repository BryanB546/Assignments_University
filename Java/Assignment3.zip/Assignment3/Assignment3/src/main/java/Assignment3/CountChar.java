//Bryan Bravo Date:4/11/21
//Assignment 3 Alice Wonderland Part 2
//Program Used Apache Netbeans 12.3
package Assignment3;

import java.lang.Character;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.IOException;
import java.io.BufferedReader;

public class CountChar {
    public static void main(String[] args) {
        int uppercase = 0;
        int lowercase = 0;
        int punctuations = 0;
        int whitespaces = 0;
        int others = 0;
        
        try {
            //Takes the file input in this case Alice in Wonderland which is located in the main folder where CountChar.java is located.
            //To test with another file change the location and Drive Letter to desired location of file.
            BufferedReader br = new BufferedReader(new FileReader("G:\\Assignment3\\Assignment3\\src\\main\\java\\Assignment3\\Alice's Adventures in Wonderland.txt"));
            int info;
            
            while ((info = br.read())!=-1) {
                if(Character.isLowerCase(info))lowercase++;
                
                else if(Character.isUpperCase(info))uppercase++;
                
                else if(info == '!' || info == ',' || info == ';' || 
                        info == '.' || info == '?' || info == '-' ||
                        info == '\'' || info == '\"' || info == ':')punctuations++;
                else if(info == ' '|| info == '\t'|| info == '\n')whitespaces++;
                else others++;
            }
            br.close();
        }
        catch (IOException b) {
            System.out.println("An Error has occurred.");
            b.printStackTrace();
        }
        try {
            //Writes results in a new file titled result2
            FileWriter Writer = new FileWriter("G:\\Assignment3\\Assignment3\\src\\main\\java\\Assignment3\\result2.txt");
            
            Writer.write("Number of uppercase letters: "+uppercase+"\n");
            Writer.write("Number of lowercase letters: "+lowercase+"\n");
            Writer.write("Number of punctuation marks: "+punctuations+"\n");
            Writer.write("Number of whitespaces: "+whitespaces+"\n");
            Writer.write("Number of others: "+others+"\n");
            Writer.close();
        }
        // Needs a catch or finally in order to function properly cause of the try but if it fails an Error has Occured message should appear.
        catch (IOException b) {
            System.out.println("An Error has occurred.");
            b.printStackTrace();
        }
    }
}