/*Bryan Bravo
Assignment 1 Part 2 3/14/21
Zip to Barcode and Viseversa conversion
ID:6059483 
Program used Apache NetBeans IDE 12.3
 */
package Part2;

import java.util.Scanner;
        

//BC = Barcode
public class BC {
    //Conversion of Zip to Barcode
    private static int processZipC(String BCode) {
        int zc = 0;
        for(int b=1; b < BCode.length()-1;b+=5) {
            String br = BCode.substring(b,b+5);
            if(br.equals("||:::"))zc = 0 + zc*10;
            if(br.equals(":::||"))zc = 1 + zc*10;
            if(br.equals("::|:|"))zc = 2 + zc*10;
            if(br.equals("::||:"))zc = 3 + zc*10;
            if(br.equals(":|::|"))zc = 4 + zc*10;
            if(br.equals(":|:|:"))zc = 5 + zc*10;
            if(br.equals(":||::"))zc = 6 + zc*10;
            if(br.equals("|:::|"))zc = 7 + zc*10;
            if(br.equals("|::|:"))zc = 8 + zc*10;
            if(br.equals("|:|::"))zc = 9 + zc*10;
            }//for loop ends
        return zc;
    
}
    // Conversion for bar into zip
    private static String processBC(int zc) {
        String BCode = "";
        
        while (zc > 0) {
            switch (zc % 10) {
                case 0:
                    BCode = "||:::" + BCode;
                    break;
                    
                    case 1:
                    BCode = ":::||" + BCode;
                    break;
                    
                    case 2:
                    BCode = "::|:|" + BCode;
                    break;
                    
                    case 3:
                    BCode = "::||:" + BCode;
                    break;
                    
                    case 4:
                    BCode = ":|::|" + BCode;
                    break;
                    
                    case 5:
                    BCode = ":|:|:" + BCode;
                    break;
                    
                    case 6:
                    BCode = ":||::" + BCode;
                    break;
                    
                    case 7:
                    BCode = "|:::|" + BCode;
                    break;
                    
                    case 8:
                    BCode = "|::|:" + BCode;
                    break;
                    
                    case 9:
                    BCode = "|:|::" + BCode;
                    break;
            }
            zc = zc /10;
        }
        BCode = "|" + BCode + "|";
        return BCode;
    }
// Display should show Zip code plus barcode and whether Barcode is valid and introduce zip again.
    public static void main(String[] args) {
        
        Scanner scanner = new Scanner(System.in);
        int zipCode; String BCode;
        
        System.out.println("Assignment 1 Part 2 Barcode");
        //Insert zip code for Barcode of said zip code.
        System.out.print("Insert Zip Code:");
        zipCode = scanner.nextInt(); scanner.nextLine();
        //Results should be the barcode of requested zipcode.
        System.out.println("Barcode result:     ");
        System.out.println(BC.processBC(zipCode));
        //User should either input barcode recieved from zip or a barcode.
        System.out.print("Input BC: ");
        BCode = scanner.nextLine();
        //Should make "Barcode Invalid pop up when inserting Bar code. Tested out with 12345 as zip code.
        if((BCode.length()< 32) || (BCode.length()> 32)) {
        System.out.println("Barcode is not valid");
        } else {
        // Should Give Zip code back when introducing Barcode
        System.out.println("Zip Code Given: ");
        System.out.println(BC.processZipC(BCode));
        
        
    
        }
    }
 
    }
    
