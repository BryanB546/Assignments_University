/*Bryan Bravo
Assignment 1 Part 1 3/12/21
ID:6059483 
Program used Apache NetBeans IDE 12.3
 */
package EmployeeProject;

public class Employee {
   //Variables Used
   private String name;
   private String gender;
   double salary;
   public static int id=0;
   
   Employee(String name,String gender,double salary){
       this.name=name;
       this.gender=gender;
       this.salary=salary;
       id=1;
   }
   //Get and Set Methods
   public String getName() {
       return name;
   }
   public void setName(String name) {
       this.name = name;
   }
   public String getGender() {
       return gender;
   }
   public void setGender(String gender) {
       this.gender = gender;
   }
   public double getSalary() {
       return salary;
   }
   public void setSalary(double salary) {
       this.salary = salary;
   }
   public int getId() {
       return id;
   }
   public void setId(int id) {
       Employee.id = id;
   }
   @Override
   public String toString() {//Displays the name, ID,Gender and salary
       return "name=" + name +", ID=" + id++ + ", gender=" + gender + ", salary=" + salary ;
   }

}