/*Bryan Bravo
Assignment 1 Part 1 3/12/21
ID:6059483 
 */
package EmployeeProject;
public class Main{
   public static void main(String args[]) {
       //EMPLOYEE OBJECTS
       Employee one=new Employee("Alice","Female",45000.0);
       Employee two=new Employee("Bob","Male",48000.0);
       Employee three=new Employee("Chris","Male",41000.0);
       Employee four=new Employee("David","Male",38000.0);
Employee five=new Employee("Emma","Female",42000);
//Print Statements showing results
       System.out.println(one.toString());
       System.out.println(two.toString());
       System.out.println(three.toString());
       System.out.println(four.toString());
       System.out.println(five.toString());
       System.out.println("next available ID is "+Employee.id+".");

       }
}
